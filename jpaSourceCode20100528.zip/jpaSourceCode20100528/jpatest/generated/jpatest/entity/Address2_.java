package jpatest.entity;

import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated("EclipseLink-2.0.2.v20100323-r6872 @ Wed May 26 16:22:36 EDT 2010")
@StaticMetamodel(Address2.class)
public class Address2_ extends BaseEntity_ {

	public static volatile SingularAttribute<Address2, String> zip;
	public static volatile SingularAttribute<Address2, String> street;
	public static volatile SingularAttribute<Address2, String> state;
	public static volatile SingularAttribute<Address2, String> city;

}