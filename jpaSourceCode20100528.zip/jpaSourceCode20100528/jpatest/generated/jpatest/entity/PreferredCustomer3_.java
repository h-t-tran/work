package jpatest.entity;

import java.util.Date;
import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated("EclipseLink-2.0.2.v20100323-r6872 @ Wed May 26 16:22:36 EDT 2010")
@StaticMetamodel(PreferredCustomer3.class)
public class PreferredCustomer3_ extends Customer3_ {

	public static volatile SingularAttribute<PreferredCustomer3, Date> expirationDate;
	public static volatile SingularAttribute<PreferredCustomer3, Double> discountRate;

}