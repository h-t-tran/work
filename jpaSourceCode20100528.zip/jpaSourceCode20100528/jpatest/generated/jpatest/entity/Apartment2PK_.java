package jpatest.entity;

import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;
import jpatest.entity.Address2PK;

@Generated("EclipseLink-2.0.2.v20100323-r6872 @ Wed May 26 16:22:36 EDT 2010")
@StaticMetamodel(Apartment2PK.class)
public class Apartment2PK_ { 

	public static volatile SingularAttribute<Apartment2PK, Address2PK> addrId;
	public static volatile SingularAttribute<Apartment2PK, Short> aptNumber;

}