package jpatest.entity;

import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated("EclipseLink-2.0.2.v20100323-r6872 @ Wed May 26 16:22:36 EDT 2010")
@StaticMetamodel(GoldCustomer5.class)
public class GoldCustomer5_ extends Customer5_ {

	public static volatile SingularAttribute<GoldCustomer5, Double> creditLimit;
	public static volatile SingularAttribute<GoldCustomer5, String> cardNumber;

}