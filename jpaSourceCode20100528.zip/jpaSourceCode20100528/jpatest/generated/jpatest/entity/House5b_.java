package jpatest.entity;

import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;
import jpatest.entity.Address2;
import jpatest.entity.Address2PK;

@Generated("EclipseLink-2.0.2.v20100323-r6872 @ Wed May 26 16:22:36 EDT 2010")
@StaticMetamodel(House5b.class)
public class House5b_ extends BaseEntity_ {

	public static volatile SingularAttribute<House5b, Address2> addr;
	public static volatile SingularAttribute<House5b, Address2PK> housePK;
	public static volatile SingularAttribute<House5b, Short> rooms;

}