package jpatest.entity;

import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated("EclipseLink-2.0.2.v20100323-r6872 @ Wed May 26 16:22:36 EDT 2010")
@StaticMetamodel(Address3PK.class)
public class Address3PK_ { 

	public static volatile SingularAttribute<Address3PK, String> zip;
	public static volatile SingularAttribute<Address3PK, String> street;

}