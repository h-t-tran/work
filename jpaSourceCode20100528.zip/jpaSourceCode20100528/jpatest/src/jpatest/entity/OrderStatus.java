package jpatest.entity;

public enum OrderStatus{ COMPLETE, FILLED, BILLED, NEW }
