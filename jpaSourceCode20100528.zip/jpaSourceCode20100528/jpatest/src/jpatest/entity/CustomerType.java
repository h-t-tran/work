package jpatest.entity;

public enum CustomerType {C, P, G}
