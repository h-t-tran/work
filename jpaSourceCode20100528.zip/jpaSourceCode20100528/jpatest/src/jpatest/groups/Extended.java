package jpatest.groups;

// a Bean Validation group that extends the default group
public interface Extended extends javax.validation.groups.Default {

}
