package jpatest.groups;

// a Bean Validation group
public interface Basic {

}
