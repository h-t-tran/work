package jpatest;

import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated("EclipseLink - Tue Dec 08 18:38:31 EST 2009")
@StaticMetamodel(Vehicle.class)
public class Vehicle_ { 

	public static volatile SingularAttribute<Vehicle, String> model;
	public static volatile SingularAttribute<Vehicle, String> vin;
	public static volatile SingularAttribute<Vehicle, Integer> year;
	public static volatile SingularAttribute<Vehicle, String> make;
	public static volatile SingularAttribute<Vehicle, Integer> version;

}